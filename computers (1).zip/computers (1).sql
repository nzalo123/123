-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2022 at 02:32 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `computers`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `category` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category`) VALUES
(1, 'Laptop'),
(2, 'Desktop'),
(3, 'Monitor'),
(4, 'Printer'),
(5, 'Keyboard'),
(6, 'Mouse'),
(7, 'Router'),
(8, 'Switch');

-- --------------------------------------------------------

--
-- Table structure for table `login_log`
--

CREATE TABLE `login_log` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `try_time` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_log`
--

INSERT INTO `login_log` (`id`, `ip_address`, `try_time`) VALUES
(1, '::1', 1652260513),
(2, '::1', 1652260519),
(3, '::1', 1652260525),
(4, '::1', 1652261142),
(5, '::1', 1652261149),
(6, '::1', 1652261412),
(7, '::1', 1652261439),
(8, '::1', 1652261496),
(9, '::1', 1652261532),
(10, '::1', 1652261796),
(11, '::1', 1652261874),
(12, '::1', 1652262233),
(13, '::1', 1652262296),
(14, '::1', 1652262302),
(15, '::1', 1652262313),
(16, '::1', 1652262378),
(17, '::1', 1652263844),
(18, '::1', 1652263893),
(19, '::1', 1652263901),
(20, '::1', 1652264479),
(21, '::1', 1652264483),
(22, '::1', 1652264729),
(23, '::1', 1652264733),
(24, '::1', 1652264739),
(25, '::1', 1652264766),
(26, '::1', 1652264840),
(27, '::1', 1652265230),
(28, '::1', 1652265242),
(29, '::1', 1652265287),
(30, '::1', 1652265298),
(31, '::1', 1652265404),
(32, '::1', 1652265409),
(33, '::1', 1652265496),
(34, '::1', 1652265677),
(35, '::1', 1652265683),
(36, '::1', 1652265754),
(37, '::1', 1652266139),
(38, '::1', 1652266542),
(39, '::1', 1652266836),
(40, '::1', 1652266843),
(41, '::1', 1652270057),
(42, '::1', 1652270139),
(43, '::1', 1652272587),
(44, '::1', 1652345242),
(45, '::1', 1652345254),
(46, '::1', 1652355473),
(47, '::1', 1652355490),
(48, '::1', 1652368943),
(49, '::1', 1652369458),
(50, '::1', 1652369549),
(51, '::1', 1652624716),
(52, '::1', 1652625161),
(53, '::1', 1652625170),
(54, '::1', 1652625176),
(55, '::1', 1652625188),
(56, '::1', 1652625439),
(57, '::1', 1652984894),
(58, '::1', 1652984902),
(59, '::1', 1652984914),
(60, '::1', 1652984924),
(61, '::1', 1653221919);

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`id`, `firstname`, `lastname`, `username`, `password`) VALUES
(36, 'Emmanuel', 'Chiramba', 'manu', 'nzalo'),
(37, 'Mary', 'Longley', 'mary', 'lu'),
(38, 'John', 'Vuligate', 'johnny', 'jay'),
(39, 'Frank', 'Johnson', 'franky', 'son'),
(40, 'Marek', 'Pieters', 'mark', 'petey'),
(41, 'Drew', 'Mlilo', 'drey', 'drew12@');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `date_created` date NOT NULL,
  `quantity` int(11) NOT NULL,
  `released_quantity` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `product_name`, `date_created`, `quantity`, `released_quantity`, `category`, `type`) VALUES
(15, 'HP Pavilion 15 Laptop', '2015-10-12', 425, 100, 'Laptop', 1),
(16, 'Dell Raven 45', '2015-10-12', 195, 5, 'Desktop', 2),
(17, 'HP DesignJet T230', '2022-05-20', 65, 5, 'Printer', 2),
(18, 'Giggabyte i230', '2016-08-01', 67, 10, 'Mouse', 2),
(19, 'HP 23 \'inch\' HD', '2011-02-14', 134, 10, 'Monitor', 2),
(20, 'Cisco RV260W VPN Router | 8 Gigabit Ethernet', '2008-12-14', 622, 30, 'Router', 2),
(21, 'Dell Inspiron i3000', '2018-05-25', 500, 0, 'Laptop', 1),
(22, 'Samsung T350 24-inch FHD', '2014-11-10', 200, 0, 'Monitor', 1),
(23, 'dell latitude 3420', '2018-10-25', 55, 0, 'Desktop', 1),
(24, 'Canon Maxify MB2140', '2000-09-15', 14, 0, 'Printer', 1),
(25, 'Gigabyte Router 432xir', '2011-10-11', 98, 0, 'Router', 1),
(26, 'TPLINK 24-port Gigabit', '2012-05-25', 99, 0, 'Switch', 1),
(27, 'Lenovo D32qc-20', '2014-04-11', 88, 0, 'Monitor', 1),
(28, 'Computer monitors  Asus 18.5 \'\' VS197DE Asus 18.5 \'\' VS197DE', '2001-01-11', 7, 0, 'Monitor', 1),
(29, 'MateView GT Monitor HUAWEI', '2018-11-24', 66, 0, 'Monitor', 1),
(30, 'Macbook air', '2012-10-20', 17, 0, 'Laptop', 1),
(31, 'Lenovo ideapad 32', '2015-11-11', 59, 0, 'Laptop', 1),
(32, 'Acer Linea 232', '2004-04-14', 24, 0, 'Laptop', 1),
(34, 'nokia', '2022-05-12', 123, 0, 'Monitor', 1),
(47, 'Acer Back Axe', '2020-11-14', 350, 0, 'Laptop', 1),
(48, 'Nokia Surface Pro', '2021-11-11', 145, 0, 'Printer', 1),
(53, 'HP DesignJet T230', '2022-01-01', 200, 0, 'Printer', 1),
(54, 'Hp', '2020-01-01', 5, 10, 'toy', 1),
(55, 'HP Pavilion 15 Laptop', '2015-10-12', 100, 0, 'Laptop', 1);

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `id` int(11) NOT NULL,
  `acceptance` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`id`, `acceptance`) VALUES
(1, 'accept'),
(2, 'release');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_log`
--
ALTER TABLE `login_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `login_log`
--
ALTER TABLE `login_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
